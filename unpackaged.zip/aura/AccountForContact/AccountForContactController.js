({    
    makePrimary: function(component, event, helper) 
    {
      	var button = event.getSource();
        button.set('v.disabled',true);
    	button.set('v.label','In Progress...');
        var contactId = component.get("v.contact.Id");
        var accountId = component.get("v.contact.Account.Id");
        var action = component.get("c.SetPrimaryContactForAccount");
        action.setParams({ 'AccountId' : accountId, 'ContactId' : contactId });
        action.setCallback(this, function(response) 
       	{
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                component.set ("v.contactAssigned",true);
                button.set('v.label','Success');
        	}
            else if (state === "ERROR") 
            {
                button.set('v.label','Failed');
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }    
        });
        $A.enqueueAction(action);
    },
    
    handleEditRecord: function(component, event, helper) 
    {
        component.find("accountNameField").set("v.value",component.get("v.contact.Account.Name"));
        component.find("accountDescriptionField").set("v.value",component.get("v.contact.Account.Description"));
        component.set ("v.editMode",true);
        
    },
    
    handleCancelEdit: function(component, event, helper) 
    {
        component.find("accountNameField").set("v.value",component.get("v.contact.Account.Name"));
        component.find("accountDescriptionField").set("v.value",component.get("v.contact.Account.Description"))
        component.set ("v.editMode",false);
    },

	handleSaveRecord: function(component, event, helper) 
    {
        var button = event.getSource();
        button.set('v.disabled',true);
    	button.set('v.label','In Progress...');
        var accountId = component.get("v.contact.Account.Id");
        var accountNameValue = component.find("accountNameField").get("v.value");
        var descriptionValue = component.find("accountDescriptionField").get("v.value");
		var action = component.get("c.UpdateAccountInformation");
        action.setParams({ 'AccountId' : accountId, 'AccountName' : accountNameValue,'AccountDescription' : descriptionValue });
        action.setCallback(this, function(response) 
       	{
            var state = response.getState();
            if (state === "SUCCESS") 
            {
        		component.set("v.editMode",false);
                button.set('v.label','Save');
                button.set('v.disabled',false);
                $A.get('e.force:refreshView').fire()
        	}
            else if (state === "ERROR") 
            {
                button.set('v.label','Failed');
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }    
        });
        $A.enqueueAction(action);
    }

})